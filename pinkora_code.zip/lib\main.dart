import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';

import 'app/routes/app_pages.dart';
import 'app/routes/app_routes.dart';
import 'app/theme/app_theme.dart';
import 'modules/cart/controllers/cart_controller.dart';
import 'modules/wishlist/controllers/wishlist_controller.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await GetStorage.init();

  await SystemChrome.setPreferredOrientations(
    const [
      DeviceOrientation.portraitUp,
    ],
  );

  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.dark,
      systemNavigationBarColor: Colors.white,
      systemNavigationBarIconBrightness: Brightness.dark,
    ),
  );

  runApp(const PinkoraApp());
}

class PinkoraApp extends StatelessWidget {
  const PinkoraApp({super.key});

  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      title: 'Pinkora',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light,

      initialRoute: AppRoutes.splash,
      getPages: AppPages.pages,

      defaultTransition: Transition.fadeIn,
      transitionDuration: const Duration(milliseconds: 180),

      initialBinding: AppBinding(),

      scrollBehavior: const MaterialScrollBehavior().copyWith(
        physics: const BouncingScrollPhysics(),
      ),
    );
  }
}

class AppBinding extends Bindings {
  @override
  void dependencies() {
    if (!Get.isRegistered<CartController>()) {
      Get.put<CartController>(
        CartController(),
        permanent: true,
      );
    }

    if (!Get.isRegistered<WishlistController>()) {
      Get.put<WishlistController>(
        WishlistController(),
        permanent: true,
      );
    }
  }
}